#ifndef _CLAVE
#define _CLAVE

#include <sys/ipc.h>

typedef int key_t;
key_t crearClave();

#endif
