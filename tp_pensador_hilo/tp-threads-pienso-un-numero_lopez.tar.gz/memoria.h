#ifndef _MEMORIA
#define _MEMORIA

void *creoMemoria(int size,int *r_id_memoria);

#endif
