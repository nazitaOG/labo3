#ifndef _SEMAFORO
#define _SEMAFORO

void crearSemaforo();
void iniciarSemaforo(int valor);
void levantaSemaforo();
void esperaSemaforo();

#endif
