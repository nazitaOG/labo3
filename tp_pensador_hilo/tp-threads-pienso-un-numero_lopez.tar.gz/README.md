Ejecutar el comando 'make all' y correr "./pensador n". Siendo n la cantidad de jugadores que van a jugar.

Cambiar NUM_MAX en def.h para ajustar la cantidad de numeros que se quiera pensar.