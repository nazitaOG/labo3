#ifndef _MEMORIA
#define _MEMORIA

void *crearMemoria(int size);
void desasociarMemoria(char *memoria);
void destruirMemoria();

#endif
