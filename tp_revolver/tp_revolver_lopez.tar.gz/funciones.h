#ifndef FUNCIONES_H
#define FUNCIONES_H

int obtener_valor_aleatorio(int min, int max);
int obtener_valor_aleatorio_sin_repetir(int min, int max, int* valores_usados);
void limpiar_programa(int sig);

#endif
