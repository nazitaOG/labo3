#ifndef DEF_H
#define DEF_H

#define TRUE 1
#define FALSE 0
#define LARGO_BUFFER 50
#define ESPERA 500
#define CANT_JUGADORES 6

#endif
