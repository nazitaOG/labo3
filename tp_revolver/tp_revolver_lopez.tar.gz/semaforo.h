#ifndef _SEMAFORO
#define _SEMAFORO

void crearSemaforo();
void iniciarSemaforo(int valor);
void levantarSemaforo();
void esperarSemaforo();

#endif
