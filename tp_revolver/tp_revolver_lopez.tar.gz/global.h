#ifndef GLOBAL_H
#define GLOBAL_H

#include <pthread.h>

extern pthread_mutex_t mutex;

#endif
