#ifndef GLOBAL_H
#define GLOBAL_H

#include <pthread.h>

extern pthread_mutex_t mutex;
extern int g_carton_lleno;

#endif
