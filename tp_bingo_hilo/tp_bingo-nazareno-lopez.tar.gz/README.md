Ejecutar el comando 'make all' y correr "./bingo n". Siendo n la cantidad de jugadores que van a jugar.

Cambiar NUMERO_MAXIMO en def.h para ajustar la cantidad de numeros que se quiera pensar.